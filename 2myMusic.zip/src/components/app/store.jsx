import { configureStore } from "@reduxjs/toolkit";
import songSlice from '../redux/song/songSlice'
import singerSlice from '../redux/singer/singerSlice'
import albumSlice from '../redux/album/albumSlice'
import categorySlice from '../redux/category/categorySlice'
import { Category } from "@mui/icons-material";



// ייבוא הפונקציה configureStore מ-@reduxjs/toolkit
export const store = configureStore({
    // הגדרת ה-reducer הראשי של ה-store
    reducer: {
        // הוספת ה-slice של השירים ל-reducer הראשי
        song: songSlice,
        // הוספת ה-slice של הזמרים ל-reducer הראשי
        singer: singerSlice,
        // הוספת ה-slice של האלבומים ל-reducer הראשי
        album: albumSlice,
        // הוספת ה-slice של הקטגוריות ל-reducer הראשי (שגיאת כתיב בשם ה-slice)
        category: categorySlice
    }
})