
import React, { useEffect, useState } from 'react'; // ייבוא React
import { Card, CardMedia, CardContent, Typography, IconButton, CardActions } from '@mui/material'; // ייבוא רכיבים מ-Material-UI
import PlayArrowIcon from '@mui/icons-material/PlayArrow'; // ייבוא אייקון Play
import FavoriteIcon from '@mui/icons-material/Favorite'; // ייבוא אייקון Favorite מלא
import FavoriteBorderIcon from '@mui/icons-material/FavoriteBorder'; // ייבוא אייקון Favorite ריק

const SongCard = ({ song, onPlay, onFavoriteToggle }) => { // הגדרת הקומפוננטה SongCard עם הפרופס song, onPlay, ו-onFavoriteToggle
  const [imageSrc, setImageSrc] = useState(""); // משתנה סטייט עבור כתובת התמונה

  useEffect(() => {
    if (song.image) {
      // המרת byte[] ל-Base64
      const base64String = arrayBufferToBase64(song.image);
      setImageSrc(`data:image/jpeg;base64,${base64String}`);
    }
  }, [song.image]);

  // פונקציה להמרת מערך Byte ל-Base64
  const arrayBufferToBase64 = (buffer) => {
    let binary = '';
    const bytes = new Uint8Array(buffer);
    bytes.forEach(b => (binary += String.fromCharCode(b)));
    return btoa(binary);
  };

  return (
    <Card sx={{ maxWidth: 345 }}> {/* כרטיס השיר עם רוחב מקסימלי של 345 */}
      <CardMedia
        component="img"
        height="300"
        //image={imageSrc} // תמונת השיר או תמונת ברירת מחדל אם אין תמונה
        image={`data:image/jpg;base64,${song.image}`} // תמונת השיר או תמונת ברירת מחדל אם אין תמונה
        alt={song.name} // טקסט חלופי לתמונה
      />
      {/* <img height="220"
        src={`data:image/jpg;base64,${song.image}`}  // זה אם ה-Base64 הוא תמונה ב-JPEG
        alt={song.name}
        loading="lazy"
      /> */}
      <CardContent>
        <Typography variant="h6">{song.name}</Typography> {/* שם השיר */}
        <Typography variant="body2" color="textSecondary">
          {song.singer} - {song.album} {/* שם הזמר והאלבום */}
        </Typography>
        <Typography variant="body2" color="textSecondary">
          Genre: {song.genre} {/* ז'אנר השיר */}
        </Typography>
      </CardContent>
      <CardActions>
        <IconButton onClick={onPlay} color="primary"> {/* כפתור הפעלה */}
          <PlayArrowIcon /> {/* אייקון Play */}
        </IconButton>
        <IconButton onClick={onFavoriteToggle} color="error"> {/* כפתור סימון כמועדף */}
          {song.favorite ? <FavoriteIcon /> : <FavoriteBorderIcon />} {/* אייקון מועדף מלא אם השיר מועדף, אחרת אייקון מועדף ריק */}
        </IconButton>
      </CardActions>
    </Card>
  );
};

export default SongCard; // ייצוא הקומפוננטה SongCard